# Site-about-selling-products
Site about selling products
- - - - - - - - - - - - - - - - - - - - 

Site about selling products with Sign In\Sign Up systems and 
adding products in the busket with connection witn data base MongoDB

It has adaptive design and validity JS and CSS codes.

It's project from my college of IT.
 Used technologies: 
    JavaScript
    => CSS
    => React
    => Node.js
    => MongoDB database
This project has been making about 2 weeks

Average time spent on programming per day: ![Average time](https://github.com/Martin13025/Site-about-selling-products/assets/115161917/9660d1f4-b5be-408c-9545-89c5cba4343e)
![Average time 2](https://github.com/Martin13025/Site-about-selling-products/assets/115161917/4a4103d6-6aa2-49bd-9c73-84ed9e1a26fd)


The number of programming languages used in this project: ![Number of programming languages](https://github.com/Martin13025/Site-about-selling-products/assets/115161917/ad5277f0-7e6f-41ab-8c3d-ba601bdf5de1)

UPD: An errors occurs on the site during authorization so that it dissappears just reload the page. After that the authorization will be successfull.

My contacts: 
    LinkedIn: www.linkedin.com/in/martin-daniels-a6b2b7269
    Telegram for contact with me: https://t.me/LuciusNumerius
    My E-mail: danpain779@gmail.com
v 1.0.0
- - - - - - - - - - - - - - - - - - - - 
# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.\
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.

### `npm run eject`

**Note: this is a one-way operation. Once you `eject`, you can't go back!**

If you aren't satisfied with the build tool and configuration choices, you can `eject` at any time. This command will remove the single build dependency from your project.

Instead, it will copy all the configuration files and the transitive dependencies (webpack, Babel, ESLint, etc) right into your project so you have full control over them. All of the commands except `eject` will still work, but they will point to the copied scripts so you can tweak them. At this point you're on your own.

You don't have to ever use `eject`. The curated feature set is suitable for small and middle deployments, and you shouldn't feel obligated to use this feature. However we understand that this tool wouldn't be useful if you couldn't customize it when you are ready for it.

## Learn More

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).

### Code Splitting

This section has moved here: [https://facebook.github.io/create-react-app/docs/code-splitting](https://facebook.github.io/create-react-app/docs/code-splitting)

### Analyzing the Bundle Size

This section has moved here: [https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size](https://facebook.github.io/create-react-app/docs/analyzing-the-bundle-size)

### Making a Progressive Web App

This section has moved here: [https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app](https://facebook.github.io/create-react-app/docs/making-a-progressive-web-app)

### Advanced Configuration

This section has moved here: [https://facebook.github.io/create-react-app/docs/advanced-configuration](https://facebook.github.io/create-react-app/docs/advanced-configuration)

### Deployment

This section has moved here: [https://facebook.github.io/create-react-app/docs/deployment](https://facebook.github.io/create-react-app/docs/deployment)

### `npm run build` fails to minify

This section has moved here: [https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify](https://facebook.github.io/create-react-app/docs/troubleshooting#npm-run-build-fails-to-minify)
