module.exports = {
    secret: 'Videotron123'
}